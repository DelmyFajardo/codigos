// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup } 
from "https://www.gstatic.com/firebasejs/9.6.10/firebase-auth.js";
import { getDatabase,ref, onValue, update, push, child}
from "https://www.gstatic.com/firebasejs/9.6.10/firebase-database.js"
import { sign } from "crypto";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDfqAcCehstcY_HmEOeINrUgLJ9L7qZR2s",
  authDomain: "delmyfajardo0907-23-11346.firebaseapp.com",
  projectId: "delmyfajardo0907-23-11346",
  storageBucket: "delmyfajardo0907-23-11346.appspot.com",
  messagingSenderId: "195012339236",
  appId: "1:195012339236:web:d0f362d75a7b578744dab1",
  measurementId: "G-KXFVLM5FMK"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

//aca inicia mi programa 
var usuarioConectado = document.getElementById ('usuarioConectado');
var botonIniciar = document.getElementById('botonIniciar');
var botonCerrar = document.getElementById('botonCerrar');
var textomensaje = document.getElementById('textomensaje');
var mensajesChat = document.getElementById ('mensajeschat');
var nombreUsuarioConectado = ""
botonIniciar.onclick = async function (){}

document.getElementById('botonIniciar').onclick = async function(){
   var auth = getAuth ();
   var providor = new GoogleAuthProvider ();
   auth.laguage = "es";
   var response = await signInWithPopup (auth, providor);
   usuarioConectado.innerText = response.user.gmail;
   botonCerrar.style.display = "block";
botonIniciar.style.display = "none";
nombreUsuarioConectado =response.user.gmail;
}  

botonCerrar.onclick = async function (){
  var auth = getAuth ();
  await auth . signOut ();
  botonCerrar.style.display = "none";
  botonIniciar.style.display = "block";
  usuarioConectado.innerText = " No conectado ";
  nombreUsuarioConectado = "";
  escucharYDibujarMensajes();

}

textomensaje.onkeydown = async function(event){
  if (event.key == "enter") {
    if (nombreUsuarioConectado == "") {
        alert ("El usuario debe iniciar sesion");
        return;
    }
    var db = getDatabase();
    var referenciaMensajes = ref (db, "mensajes");
    var nuevaLlave = push (child (ref (db), " mensajes ") ).key;
    var nuevoDatos = {
       [nuevaLlave] :
      {
        usuario:nombreUsuarioConectado,
        mensaje: textomensaje.value,
        fecha: new Date(). toLocaleDateString()
      }
     
    }
    textomensaje.value =""
    update (referenciaMensajes, nuevoDatos)
  }  
}
 
function escucharYDibujarMensajes () {
  //referencia a base de datos firebase
  var db = getDatabase ();
  var referenciaMensajes = ref (db, "mensajes");
  onValue (referenciaMensajes,function (datos) {
    var valoresObtenidos = datos.val();
    // console.log( valoresObtenidos)
    mensajesChat.innerHTML="";
     Object.keys(valoresObtenidos).forEach(llave =>{
     var mensajedescargado= valoresObtenidos[llave];
     var mensajes = "";
     mensajes = "< div class='nombre usuario' >"+ mensajedescargado.mensajes.usuario + "</div>";
     mensajes += "< div class='mensajechat' >"+ mensajedescargado.mensajes + "</div>"
     
     mensajes += "< div >"+ mensajedescargado.mensajes.fecha + "</div><hr/>";
     mensajesChat.innerHTML += mensajes;
    })
   
  })
  
}